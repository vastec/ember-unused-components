module.exports = {
  whitelist: ['z-button'],
  ignore: [
    'app/templates/freestyle.hbs', // this is our template with style guides
  ],
};
