import Component from '@ember/component';
import layout from '../templates/components/mini-button';

export default Component.extend({
  layout
});
