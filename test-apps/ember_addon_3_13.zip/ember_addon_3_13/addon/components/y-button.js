import XButton from 'ember-addon-3-13/components/x-button';

export default XButton.extend({});

/*
  *** TEST CASE - find ***

  Testing support for importing components and extending by other components.
*/
