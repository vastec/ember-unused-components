import Component from '@ember/component';
import layout from '../templates/components/medium-button';

export default Component.extend({
  layout
});
